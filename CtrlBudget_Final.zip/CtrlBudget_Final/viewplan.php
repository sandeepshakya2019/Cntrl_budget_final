<?php
    session_start();
    // take the session variable
    $em = $_SESSION['Email'];
    $title_1 = $_SESSION['title_1'] ;

    //echo $title_1.$em;
    // if anyone opens directly this page it transfer to you at logout.php
    if (strlen($_SESSION['Email']) == 0) {
      header('location:logout.php');
      } 
    //connection to the databse
    $con = mysqli_connect("localhost", "root","", "ctrlproject") or die(mysqli_error($con));
    //select query to select to items from plandetail table
    $select_query = "SELECT title, fromdate, todate, initialbudget , nopeople FROM plandetail where email = '$em' and title = '$title_1' ";
    $select_query_result = mysqli_query($con, $select_query) or die(mysqli_error($con));
    //if button whose name is add is set
    if (isset($_POST['add'])){
        $expensename = mysqli_real_escape_string($con, $_POST['expensename']);
        $date = mysqli_real_escape_string($con, $_POST['date']);
        $amountspend = mysqli_real_escape_string($con, $_POST['amountspend']);
        $choose = mysqli_real_escape_string($con, $_POST['choose']);
        //$bill = mysqli_real_escape_string($con, $_POST['uploadedimage']);
        //$user_added_query = "insert into addnewexpense (title ,email, expensename, dated, amountspend, choose, uploadedimage) values ('$title_1', '$em', '$expensename', '$date', '$amountspend', '$choose','$uploadedimage')";
        //$user_added_submit = mysqli_query($con, $user_added_query) or die(mysqli_error($con));
        //echo "<script>alert('Successfully updated')</script>";

        function GetImageExtension($imagetype){
            if(empty($imagetype)) return false;
            switch($imagetype){
            case 'image/bmp': return '.bmp';
            case 'image/gif': return '.gif';
            case 'image/jpeg': return '.jpg';
            case 'image/png': return '.png';
            default: return false;
            }
        }
        if (!empty($_FILES["uploadedimage"]["name"])) {
            $file_name=$_FILES["uploadedimage"]["name"];
            $temp_name=$_FILES["uploadedimage"]["tmp_name"];
            $imgtype=$_FILES["uploadedimage"]["type"];
            $ext= GetImageExtension($imgtype);
            $imagename=date("d-m-Y")."-".time().$ext;
            $target_path = "img/".$imagename;
            if(move_uploaded_file($temp_name, $target_path)){
                $user_added_query = "insert into addnewexpense (title ,email, expensename, dated, amountspend, choose,uploadedimage) values ('$title_1', '$em', '$expensename', '$date', '$amountspend', '$choose','$target_path')";
        $user_added_submit = mysqli_query($con, $user_added_query) or die(mysqli_error($con));
                
                
            }
        }
            else{
            $user_added_query = "insert into addnewexpense (title ,email, expensename, dated, amountspend, choose) values ('$title_1', '$em', '$expensename', '$date', '$amountspend', '$choose')";
        $user_added_submit = mysqli_query($con, $user_added_query) or die(mysqli_error($con));
        }
        

        $em = $_SESSION['Email'];
        //$_SESSION['amountspend'] = $amountspend_1;
        $_SESSION['title_1'] = $title_1 ;
        header("location:addnewexpense.php");
    }
    




?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>View Plan</title>
        <!-- Bootstrap Core CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!--SelfDefine CSS-->
        <link rel="stylesheet" href="styles.css" type="text/css" >
        
    </head>
    <style type="text/css">
        body{
            margin-bottom: 50px;
        }
        .container_view{
            margin-top: 50px
        }
        .expense_btn{
            margin-top: 100px;
        }
        .expensebtn{
            background-color: white;
            border: 1px solid #008080;
            color:  #008080;
            text-align: center;
            width: 200px;      
        }
        .addbtn{
            background-color: white;
            border: 1px solid #008080;
            color:  #008080;
            text-align: center;
        }
        .bg_1{
            background-color: #388a79;
            color: white;
            padding-top: 10px;
            padding-bottom: 10px;
        }
        .bg{
            background-color: #388a79;
        }
    </style>

    <body style="padding-top: 50px;">
        <!-- Header -->
        <?php include"resource/header.php";?>
        <!--Header End-->

        <!--Changepasswor content -->
        


        <div class="container container_view" >
            <div class="row">
                <?php while ($row = mysqli_fetch_array($select_query_result)) { ?>
                <div class="col-lg-6"  >
                   <div class="container_fluid">
                        <div class="card border" style="width: 500px">
                        <div class="card-header bg">
                        <div class="row">
                            <div class="col-lg-10 col-md-10 col-xs-8 col-sm-9" style="text-align: center;">
                                <h4><?php echo $row['title'] ?></h4>

                            </div>
                            <div class="col-lg-2 col-md-2 col-xs-4 col-sm-3" style="text-align: left;">
                                <h4 dir="rtl"><?php echo $row['nopeople'] ?>&nbsp;<span class="glyphicon glyphicon-user"></span></h4>
                            </div>
                        </div>
                        </div>
                        <div class="card-body">
                            <p>
                                <div class="row">
                                    <div class="col-lg-9 col-md-9 col-sm-8 col-xs-6">
                                        <h5>Budget</h5>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-4 col-xs-6 ">
                                        <h5 dir="rtl"><?php echo $row['initialbudget']." ₹" ?> </h5>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-9 col-md-9 col-sm-8 col-xs-7">
                                        <h5>Remaining Budget</h5>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-4 col-xs-5 ">
                                        <h5 dir="rtl" style="color: green"><?php echo $row['initialbudget']." ₹" ?> </h5>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-7 col-md-9 col-sm-8 col-xs-3" >
                                        <h5>Date</h5>
                                    </div>
                                    <div class="col-lg-5 col-md-3 col-sm-4 col-xs-9" >
                                        <?php  
                                                $orgDate =$row['fromdate'] ;  
                                                $fromDate = date("Y-m-d", strtotime($orgDate));  
                                                global $fromDate;
                                                //echo "New date format is: ".$newDate. " (MM-DD-YYYY)";  
                                                $orgDate1 =$row['todate'] ;  
                                                $toDate = date("Y-m-d", strtotime($orgDate1));
                                            ?>
                                        <h5 style="float: right;"><?php echo $fromDate . " to " . $toDate ?></h5>
                                        
                                    </div>
                                </div>
                            </p>
                        </div> 
                        
                    </div>
                   </div>
                </div>
            <?php }?>
                <center>
                    <div class="col-lg-6 expense_btn" >
                        <a href="expensedistribution.php" class="btn expensebtn">Expense Distribution</a>
                    </div>
                </center>
                <br>
                
            </div>
        </div>

        <div class="container  " id="content">
            <div class="row">
                <div class="col-lg-8">
                </div>
                <div class="col-lg-4 border">
                    <h4 class="bg_1"><center>Add New Expense</center></h4>
                    <form  action="viewplan.php"  method="POST" enctype="multipart/form-data">
                       
                            
                            <div class="form-group">
                                <label for="title" class="paddings">Title</label>
                                <input type="text" class="form-control" placeholder="Expense Name" name="expensename"  required>
                            </div>
                        
                            <div class="form-group">
                                <label for="date" class="paddings">Date</label>
                                <input type="date" class="form-control"  placeholder="Date" min="<?php echo $fromDate?>"  max="<?php echo $toDate ?>" name="date" required>
                                
                            </div>
                            <div class="form-group">
                                <label for="amountspend" class="paddings">Amount Spend</label>
                                <input type="number" class="form-control" placeholder="Amount Spend" name="amountspend" min="0" required>
                           
                            </div>
                            <div class="form-group">
                                <label for="amountspend" class="paddings">Choose</label>
                                <select class="form-control" id="inlineFormCustomSelectPref" name="choose" required>
                                    <option value="1">First</option>
                                    <option value="2">Second</option>
                                </select>
                                
                            </div>
                            <div class="form-group">
                                <label for="fi₹tname" class="paddings">Uplaod Bill</label>
                                <input type="file" class="form-control" name="uploadedimage">
                                
                            </div>
                            <br>
                            <button type="submit" name="add" class="btn btn-block addbtn"> ADD</button><br>
                    </form>
                </div>
            </div>
        </div>
        


        
        <!--Footer-->
        <?php include"resource/footer.php" ; ?>
        <!--Footer end-->


        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>



    </body> 
</html>

