<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>About Us</title>
		<!-- Bootstrap Core CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
		<!--Self Defined CSS-->
		<link rel="stylesheet" href="styles.css" type="text/css" >
	</head>

	<body style="padding-top: 30px;margin-bottom: 50px;">
		<!-- Header -->
		<?php include 'resource/header.php'; ?>
		<!--Header End-->

		<!--About us content -->
		<div class="container">
			
			<div class="row cont">

				<div class="col-lg-6 col-md-6 col-sm-6 " >
					<h3 style="font-weight: bold;font-size: 20px">Who are We ?</h3>
					<p style="font-size:15px " >We are the group of young technocrats who came up with an idea of solving budget and time issues which we usually face in our daily lives.We are here to provide a budget controller according to your aspects.<br><br>Budget Control is the biggest finacial issues in the present world one should look after their budgetcontrol to get rid off form their finacial problem.</p>
			        <br><br>
					<h3 style="font-weight: bold;font-size: 20px">Contact Us</h3>
					<p style="font-size:15px "><b>Email:</b>training@internshala.com<br><br><b>Mobile:</b>+91-8448444853</p>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-6" >
					<h3 style="font-weight: bold;font-size: 20px">Why Choose Us ?</h3>
					<p style="font-size:15px " >We provide with predominant way to controland manage your budget estimation with easeof accessing for multiple users.</p>
				</div>
			</div>
		</div>
        <!--End Of About us content -->

		<!--Footer-->
		<?php include 'resource/footer.php'?>
		<!--Footer end-->

		<!--jQuery library--> 
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    	<!--Latest compiled and minified JavaScript--> 
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</body> 
</html>