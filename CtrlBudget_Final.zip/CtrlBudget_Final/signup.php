<?php
session_start();

//Connection to database
$con = mysqli_connect("localhost", "root","", "ctrlproject") or die(mysqli_error($con));

if (isset($_POST['signup'])){
    //Register user
    $name = mysqli_real_escape_string($con, $_POST['Name']);
    $email = mysqli_real_escape_string($con, $_POST['Email']);
    //Email Validation ==> We already validate it by using html
    $password = mysqli_real_escape_string($con, $_POST['Password']);
    //Check Length of password if it is greater than or equal to 6 then it validates 
    if (strlen($password) >= 6){
        //for only numeric in contact 
        $contact = $_POST['Contact'];
        if (is_numeric($contact)) {
            //Check for the existing user with help of databse
            $select_query = "select * from signup where Email = '$email' or Contact = '$contact' ";
            $result = mysqli_query($con, $select_query) or die(mysqli_error($con));
            $user = mysqli_fetch_assoc($result);
            if ($user){
                if($user['Email']===$email){
                    echo "<script>alert('Email Address Alredy Exist')</script>";
                } 
                if($user['Contact']===$contact){
                    echo "<script>alert('Contact Alredy Exist')</script>";
                }
            }
            //register the user if there is no error
           
            else{
                $pass = md5($_POST['Password']) ;//Enctrypted password
                $user_registration_query = "insert into signup (Name, Email, Password, Contact) values ('$name', '$email', '$pass', '$contact')";
                $user_registration_submit = mysqli_query($con, $user_registration_query) or die(mysqli_error($con));
                echo "<script>alert('User Succesfully Registered')</script>";
                $_SESSION['Email'] = $email;
                header('location:home.php');
            }
            } 
            else{
            echo "<script>alert('Wrong Mobile Number')</script>";
            }
        

        }else{
        echo "<script>alert('Minimum 6 Digits required')</script>";
    }

    
}    

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Sign Up</title>
        <!-- Bootstrap Core CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!--style.css-->
        <link rel="stylesheet" href="styles.css" type="text/css">
    </head>

    <body style="padding-top: 100px;">

        <!-- Header -->
        <?php include 'resource/header.php'; ?>
        <!--Header end-->

        

        <!--signup form-->
        <div class="container-fluid" id="content">
            <div class="row">
                <div class="container ">
                    <div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4 border" >
                        <div>
                            <center><h3>SIGN UP</h3></center>
                            <form  action="signup.php" method="POST"><hr>
                                <div class="form-group">
                                    <label for="name" >Name</label>
                                    <input class="form-control" placeholder="Name" name="Name"  required>
                                </div>
                                <div class="form-group">
                                    <label for="firstname">Email</label>
                                    <input type="email" class="form-control"  placeholder="Email"  name="Email" required>
                                </div>
                                <div class="form-group">
                                    <label for="firstname">Password</label>
                                    <input type="password" class="form-control" placeholder="Password(at least contain 6 digit)"  name="Password" required>
                                </div>
                                <div class="form-group">
                                    <label for="firstname">Contact</label>
                                    <input type="tel" class="form-control"  placeholder="Contact" minlength="10" maxlength="10" size="10" name="Contact"  required>
                                </div>
                                <br>
                                <button type="submit" name="signup" class="btn btn-block signup"><span class="glyphicon glyphicon-user"></span> Sign Up</button>
                                    
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--signup form-->


        <!--Footer-->
        <?php include 'resource/footer.php'?>
        <!--Footer end-->

        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


    </body> 
</html>