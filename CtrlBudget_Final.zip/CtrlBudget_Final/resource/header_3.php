
<div class="navbar navbar-inverse navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>                        
                    </button>
                    <a class="navbar-brand" href="home2.php">CtrlBudget</a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="aboutus2.php"><span class="glyphicon glyphicon-info-sign"></span> About Us</a></li>
                        <li><a href="changepassword.php"><span class="glyphicon glyphicon-cog"></span><?php $_SESSION['Email']?> Change Password</a></li>
                        <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> LogOut</a></li>
                    </ul>
                </div>
            </div>
        </div>