<footer>
    <div class="container">
	    <center>
			<p>Copyright © Control Budget. All Rights Reserved|Contact Us: +91-8448444853.</p>	
		</center>
	</div>
</footer>