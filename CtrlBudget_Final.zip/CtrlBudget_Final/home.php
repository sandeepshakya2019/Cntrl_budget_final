<?php 
session_start();
$email = $_SESSION['Email'];
// if anyone opens the page direcly the it send to logout.php
if (strlen($_SESSION['Email']) == 0) {
  header('location:logout.php');
  } 
//if button whose name is create is pressed then it takes to createnewplan.php page
if (isset($_POST['create'])){
    $_SESSION['Email'] = $em;
    header('location:createnewplan.php');
}

?>
<?php if(strlen($_SESSION['Email']) != 0) { ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Home</title>
        <!-- Bootstrap Core CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <link rel="stylesheet" href="styles.css" type="text/css">
        <style type="text/css">
            @media only screen and (max-width: 600px) {
              .jumbotron{
                float: left;
              }
            }
        </style>
    </head>
    <body style="padding-top: 50px;">
        <!-- Header -->
        <?php include 'resource/header.php'; ?>
        <!--Header End--> 

        <!--Home Page content -->
        
            <div class="jumbotron" style="background-color:white;">
            <div class="container">
                <h3 class="display-4">You don't Have any active plans</h3>
                <p class="lead"></p>
                <hr class="my-4">
                <center>
                <p class="para"name="create" style="background-color: #f8f8f8"><a href="createnewplan.php" style="color:green"><span class="glyphicon glyphicon-plus-sign"></span>  Create a New plan</a></p>
            </center>
            </div>
        </div>
                


        
        <!--end of Home Page content -->

            <!--Footer-->
            <?php include"resource/footer.php"?>
            <!--Footer end-->

            <!--jQuery library--> 
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

            <!--Latest compiled and minified JavaScript--> 
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

           

    </body> 
</html>
<?php } else { 
    echo "<script>alert('You are Logged out')</script>";
    echo ("<script>location.href='login.php'</script>");
}
?>
