<?php

session_start();
$em = $_SESSION['Email'];
$title_1 = $_SESSION['title_1'] ;

//$amountspend_1 = $_SESSION['amountspend'];
//echo $amountspend_1.$em;
// if anyone opens directly this page it transfer to you at logout.php
if (strlen($_SESSION['Email']) == 0) {
  header('location:logout.php');
  } 
$em = $_SESSION['Email'];
$con = mysqli_connect("localhost", "root","", "ctrlproject") or die(mysqli_error($con));

$select_query = "SELECT email, expensename, dated, amountspend, choose , uploadedimage FROM addnewexpense where email = '$em' and title = '$title_1' ";
$select_query_result = mysqli_query($con, $select_query) or die(mysqli_error($con));

//$se = "SELECT nopeople,initialbudget,todate,fromdate , initialbudget - amountspend AS amount FROM plandetail INNER JOIN addnewexpense ON plandetail.email = addnewexpense.email";
//$select_query_result_2 = mysqli_query($con, $se) or die(mysqli_error($con));

$select_query_3 = "SELECT title, fromdate, todate, initialbudget , nopeople FROM plandetail where email = '$em' and title = '$title_1' ";
$select_query_result_3 = mysqli_query($con, $select_query_3) or die(mysqli_error($con));

if (isset($_POST['add'])){
        $expensename = mysqli_real_escape_string($con, $_POST['expensename']);
        $date = mysqli_real_escape_string($con, $_POST['date']);
        $amountspend = mysqli_real_escape_string($con, $_POST['amountspend']);
        $choose = mysqli_real_escape_string($con, $_POST['choose']);
        
        function GetImageExtension($imagetype){
            if(empty($imagetype)) return false;
            switch($imagetype){
            case 'image/bmp': return '.bmp';
            case 'image/gif': return '.gif';
            case 'image/jpeg': return '.jpg';
            case 'image/png': return '.png';
            default: return false;
            }
        }
        if (!empty($_FILES["uploadedimage"]["name"])) {
            $file_name=$_FILES["uploadedimage"]["name"];
            $temp_name=$_FILES["uploadedimage"]["tmp_name"];
            $imgtype=$_FILES["uploadedimage"]["type"];
            $ext= GetImageExtension($imgtype);
            $imagename=date("d-m-Y")."-".time().$ext;
            $target_path = "img/".$imagename;
            //echo $target_path."hgjhdsjfhkjdfhvnksjd";
            //$taget = "Photo uploaded";
            if(move_uploaded_file($temp_name, $target_path)){
                

                $user_added_query = "insert into addnewexpense (title ,email, expensename, dated, amountspend, choose,uploadedimage) values ('$title_1', '$em', '$expensename', '$date', '$amountspend', '$choose','$target_path')";
        $user_added_submit = mysqli_query($con, $user_added_query) or die(mysqli_error($con));
                
                
            }
        }
        else{
            $user_added_query = "insert into addnewexpense (title ,email, expensename, dated, amountspend, choose) values ('$title_1', '$em', '$expensename', '$date', '$amountspend', '$choose')";
        $user_added_submit = mysqli_query($con, $user_added_query) or die(mysqli_error($con));
        }

        //echo "<script>alert('Successfully updated')</script>";
        //$em = $_SESSION['Email'];
        //$_SESSION['amountspend'] = $amountspend_1;
        //$_SESSION['title_1'] = $title_1 ;

        header("location:addnewexpense.php");

        

    }



    ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Add New Expenses</title>
        <!-- Bootstrap Core CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!--SelfDefine CSS-->
        <link rel="stylesheet" href="styles.css" type="text/css" >
        
    </head>
    <style type="text/css">
        .container_view{
            margin-top: 50px
        }
        .expense_btn{
            margin-top: 100px;
            
 
        }
         .expensebtn{
            background-color: white;
            border: 1px solid #008080;
            color:  #008080;
            text-align: center;
            width: 200px;      
        }
        .bg_1{
            background-color: #388a79;
            color: white;
            padding-top: 10px;
            padding-bottom: 10px;
        }
        .addbtn{
            background-color: white;
            border: 1px solid #008080;
            color:  #008080;
            text-align: center;
        }
        
        .bg{
            background-color: #388a79;
        }
        .border{

        }
    </style>


<?php
  //function to take the initial budget from table
function initialbudget($con, $amount) {
    global $em;
    global $title_1;
    //echo $em.$title_1;
    $se_2 = "SELECT *  FROM plandetail where email = '$em' and title = '$title_1'  ";
    $select_query_result_2 = mysqli_query($con, $se_2) or die(mysqli_error($con));
    $row = mysqli_fetch_array($select_query_result_2);
    return $row['initialbudget'];
}
function totalamountspend($con, $amount) {
    global $em;
    global $title_1;
    //echo $em.$title_1;
    $se_2 = "SELECT *  FROM addnewexpense where email = '$em' and title = '$title_1' ";
    $select_query_result_2 = mysqli_query($con, $se_2) or die(mysqli_error($con));
    $add_3 = 0;
    while($row = mysqli_fetch_array($select_query_result_2)){
        $add_3 = $add_3 + $row['amountspend'];
    }
    return $add_3;
}



  


?>
<body style="padding-top: 50px; margin-bottom: 50px;">
<!-- Header -->
    <?php include"resource/header.php";?>
<!--Header End-->
        
        
<!--View PLan Page-->
        <div class="container container_view" >
            <div class="row">

                
                <div class="col-lg-6 col-md-6 "  >
                   <div class="container_fluid">
                        <div class="card border" style="width: 500px">
                        <div class="card-header bg">
                            <?php while ($row = mysqli_fetch_array($select_query_result_3)) {
                            $totalamountspend = totalamountspend($con, $row['initialbudget']) ;
                            $initialbudget = initialbudget($con, $row['initialbudget']);?>
                        <div class="row">
                            <div class="col-lg-10 col-md-10 col-xs-8 col-sm-10">
                                <h4><?php echo $row['title'] ?></h4>

                            </div>
                            
                            <div class="col-lg-2 col-md-2 col-xs-4 col-sm-2">
                                <h4 dir="rtl"><span class="glyphicon glyphicon-user"></span><?php echo $row['nopeople'] ?></h4>
                            </div>
                        </div>
                        </div>
                        <div class="card-body">
                            <p>
                                <div class="row">
                                    <div class="col-lg-9 col-md-9 col-sm-8 col-xs-7">
                                        <h5>Budget</h5>
                                    </div>
                                    <div class="col-lg-3">
                                        <h5 dir="rtl"><?php echo $row['initialbudget']." ₹";?> </h5>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-7 col-md-7 col-sm-8 col-xs-5">
                                        <h5>Remaining Budget</h5>
                                    </div>
                                    <div class="col-lg-5">
                                        <h5 dir="rtl" <?php if (($initialbudget - $totalamountspend) > 0){ echo 'style = "color :green"';}
                                        else{echo 'style = "color :red"';} ?> > <b><?php if (($initialbudget - $totalamountspend) > 0) {echo ($initialbudget - $totalamountspend)." ₹" ;}
                                        else {echo abs($initialbudget - $totalamountspend)." Overspend By";}  ?> </b></h5>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-8 col-xs-3 ">
                                        <h5>Date</h5>
                                    </div>
                                    <div class="col-lg-6 col-md-6" style="text-align: right">
                                    <?php  
                                                $orgDate =$row['fromdate'] ;  
                                                $fromDate = date("Y-m-d", strtotime($orgDate));  
                                                //echo "New date format is: ".$newDate. " (MM-DD-YYYY)";  
                                                $orgDate1 =$row['todate'] ;  
                                                $toDate = date("Y-m-d", strtotime($orgDate1));
                                            ?>
                                        <h5 ><?php echo $fromDate . " to " . $toDate ?></h5>
                                    </div>
                                </div>

                            </p>
                        </div> 
                        
                    </div>
                   </div>
                </div>
            <?php }?>
            <center>
                    <div class="col-lg-6 col-md-6 expense_btn" >
                        <a href="expensedistribution.php" class="btn btn-primary expensebtn">Expense Distribution</a>
                    </div>
            </center>
            <br>
            </div>
        </div>
<!--View PLan Page-->

 
<br>
<!--Add New Expense Page-->
        <div class="container" id="content">
            <div class="row">
                <div class="col-lg-8 col-md-8">
                    <div class="row">
                        <div class="container-fluid ">
                            <?php  while ($row = mysqli_fetch_array($select_query_result)) { ?>
                                <div class="card ">
                                    <div class="col-lg-4 col-md-4 "  >
                                        <div class="card-header bg ">
                                            <center>
                                                <div class="row">
                                                    <div class="col-lg-7 col-md-7 col-xs-7">
                                                        <h5><?php echo $row['expensename'];?></h5>
                                                    </div>
                                                </div>
                                            </center>
                                        </div>

                                        <div class="card-body">
                                            <p>
                                                <div class="row">
                                                    <div class="col-lg-8 col-md-7 col-sm-5 col-xs-5">
                                                        <h5>Amount</h5>
                                                    </div>
                                                    <div class="col-lg-4 col-md-5">
                                                        <h5 dir="rtl"><?php echo $row['amountspend']." ₹";?> </h5>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-lg-8 col-md-8 col-sm-5 col-xs-5">
                                                        <h5>Paid By</h5>
                                                    </div>
                                                    <div class="col-lg-4 col-md-4">
                                                        <h5 dir="rtl" ><?php echo $row['choose'] ?></h5>
                                                    </div>
                                                </div>
                                
                                                <div class="row">
                                                    <div class="col-lg-6 col-md-4 col-xs-7">
                                                        <h5>Paid On</h5>
                                                    </div>
                                                    <div class="col-lg-6 col-md-8">
                                                    	<?php  
			                                                $orgDate =$row['dated'] ;  
			                                                $expenseDate = date("d-m-Y", strtotime($orgDate));  
			                                                //echo "New date format is: ".$newDate. " (MM-DD-YYYY)";  
			                                                
			                                            ?>
                                                        <h5  dir="rtl"><?php echo $expenseDate ?></h5>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <center>
                                                    <?php if ($row['uploadedimage'] == True){?>
                                                        <a href="#"><h5>You Have a Bill</h5></a>
                                                    <?php }
                                                    
                                                    else {echo "<h5>You Have No bill</h5>";}
                                                    ?>
                                                    </center>
                                                    
                                                </div>
                                            </p>
                                        </div> 

                                    <br>
                                     
                                    </div>
                                   
                               </div>
                               
                            <?php } ?> 
                            </div>
                            
                            </div>
                        <br>
                </div>
                
                <div class="col-lg-4  col-md-4 border" >
                    <h4 class="bg_1"><center>ADD NEW EXPENSE</center></h4>
                    <form  action="addnewexpense.php"  method="POST" enctype='multipart/form-data'>
                       
                            
                            <div class="form-group">
                                <label for="title" class="paddings">Title</label>
                                <input type="text" class="form-control" placeholder="Expense Name" name="expensename"  required>
                            </div>
                        
                            <div class="form-group">
                                <label for="date" class="paddings">Date</label>
                                <input type="date" class="form-control"  placeholder="Date" min="<?php echo $fromDate?>"  max="<?php echo $toDate ?>" name="date" required>
                                
                            </div>
                            <div class="form-group">
                                <label for="amountspend" class="paddings">Amount Spend</label>
                                <input type="number" class="form-control" placeholder="Amount Spend" name="amountspend" min="0" required>
                           
                            </div>
                            <div class="form-group">
                                <label for="amountspend" class="paddings">Choose</label>
                                <select class="form-control" id="inlineFormCustomSelectPref" name="choose" required>
                                    <option value="1">First</option>
                                    <option value="2">Second</option>
                                </select>
                                
                                
                            </div>
                            
                            

                                <div class="form-group">
                                    <label for="uploadimage" class="paddings">Uplaod Bill</label>
                                    <input type="file"  class="form-control" name="uploadedimage" value="upload">
                                </div>
                                        
                                
                            <br>
                            <button type="submit" name="add" value="upload" class="btn btn-primary  btn-block addbtn "> ADD</button><br>
                    </form>
                </div>
            </div>
        </div>
        
<!--Add New Expense Page-->     




        
        <!--Footer-->
        <?php include"resource/footer.php" ; ?>
        <!--Footer end-->


        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>



    </body> 
</html>

