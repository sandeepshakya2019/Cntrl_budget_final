<?php 
  session_start();
  // if anyone opens the page direcly the it send to logout.php
  if (strlen($_SESSION['Email']) == 0) {
    header('location:logout.php');
    } 
  //take the session variable
  $em = $_SESSION['Email'];
  $initialbudget =$_SESSION['initialbudget'];
  $nopeople = $_SESSION['noofpeople'];
  //Connection to the database
  $con = mysqli_connect("localhost", "root","", "ctrlproject") or die(mysqli_error($con));
  //if button whose name is plane_submit is pressed
  if (isset($_POST['plan_submit'])){
    $title = mysqli_real_escape_string($con, $_POST['title']);
    $fromdate = mysqli_real_escape_string($con, $_POST['fromdate']);
    $todate = mysqli_real_escape_string($con, $_POST['todate']);
    $initialbudget = mysqli_real_escape_string($con, $_POST['initialbudget']);
    $nopeople = mysqli_real_escape_string($con, $_POST['nopeople']);
    $person1name = mysqli_real_escape_string($con, $_POST['person1name']);
    $person2name = mysqli_real_escape_string($con, $_POST['person2name']);
    //insert query to insert all the details
    $user_registration_query = "insert into plandetail (email, title, fromdate, todate, initialbudget,nopeople,person1name,person2name) values ('$em','$title', '$fromdate', '$todate', '$initialbudget','$nopeople','$person1name','$person2name')";
    $user_registration_submit = mysqli_query($con, $user_registration_query) or die(mysqli_error($con));
    $_SESSION['title'] = $title;
    //echo Your New Budget Planner Added Succesfully
    echo "<script>alert('Your New Budget Planner Added Succesfully')</script>";
    //move to home2.php
    echo ("<script>location.href='home2.php'</script>");
  }

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Plan Detail</title>
        <!-- Bootstrap Core CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!--own stylesheet-->
        <link rel="stylesheet" href="styles.css" type="text/css">
        <style>
          #content_full{
              min-height: 500px;
          }.btn {
              background-color: white;
              border: 1px solid #008080;
              color:  #008080;
              text-align: center;
            }
            .decor_bg{
              margin:50px 0px 0px 100px;
            }
        </style>
    </head>

<body style="padding-top: 50px;">
<!-- Header -->
        <?php include 'resource/header_2.php'; ?>
<!--Header End-->

<!--Create a new plan Page content -->
          <form action="plandetail.php" method="POST" >
            <div class="container-fluid decor_bg  " id="content_full" >
              <div class="row" >
                  <div class="container">
                    <div class="col-lg-6 col-lg-offset-2 col-md-6 col-md-offset-2 border">
                      <div class="form-group">
                        <label for="title">Title</label>
                        <input type="text" class="form-control" id="title" name = "title" placeholder="Enter Title" required>
                      </div>
                      <div class="row">
                        <div class="form-group col-lg-6">
                          <label for="from">From</label>
                          <input type="date" class="form-control" id="from" name = "fromdate" min="2019-04-01"  max="2019-04-20" required>
                        </div>
                        <div class="form-group col-lg-6">
                          <label for="to">To</label>
                          <input type="date" class="form-control" id="to" name = "todate" min="2019-04-01"  max="2019-04-20" required >
                        </div>
                      </div>
                      <div class="row">
                        <div class="form-group col-lg-8">
                          <label for="initialBudget">Initial Budget</label>
                          <input type="number" class="form-control" id="initialBudget" name = "initialbudget" value=<?php echo $initialbudget ?> readonly>
                        </div>
                        <div class="form-group col-lg-4">
                          <label for="noofpeople">No. of people</label>
                          <input type="number" class="form-control" id="noofpeople" name = "nopeople"  value=<?php echo $nopeople ?> readonly>
                        </div>
                      </div>
                      <?php
                    for ($i = 1; $i <= $nopeople; $i++) { ?>
                      <div class="form-group">
                        <label for="person2">Person <?php echo $i ?></label>
                        <input type="text" class="form-control" id="person<?php echo $i ?>" name = "person<?php echo $i ?>name" placeholder="Person<?php echo $i ?> Name" required>
                      </div>
                        
                    <?php } ?>
                      
                      <button type="submit" name = 'plan_submit' class="btn btn-block">Submit</button>
                  </div>
                </div>
              </div>
            </div>
        </form>
<!--end of Create a new plan Page content -->

<!--Footer-->
         <?php include"resource/footer.php"?>
<!--Footer end-->

<!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    </body> 
</html>