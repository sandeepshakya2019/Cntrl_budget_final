<?php 
session_start();
// if anyone opens directly this page it transfer to you at logout.php
if (strlen($_SESSION['Email']) == 0) {
  header('location:logout.php');
  } 
//take the session variable
$em = $_SESSION['Email'];
//connection to the database
$con = mysqli_connect("localhost", "root","", "ctrlproject") or die(mysqli_error($con));
//use select query to take all the plans
$select_query = "SELECT id, title, fromdate, todate, initialbudget , nopeople FROM plandetail where email = '$em' ";
$select_query_result = mysqli_query($con, $select_query) or die(mysqli_error($con));
//if button whose name is viewplan is set 
if(isset($_GET['id']))
{
$title_1 = $_GET['id'];
$_SESSION['Email'] = $em;
$_SESSION['title_1'] = $title_1;
//echo $titl;
$select_query = "SELECT email, expensename, dated, amountspend, choose  FROM addnewexpense where email = '$em' and title = '$title_1' ";
$select_query_result = mysqli_query($con, $select_query) or die(mysqli_error($con));
$total_rows_fetched = mysqli_num_rows($select_query_result);
echo $total_rows_fetched;
if ($total_rows_fetched == 0) {header("location:viewplan.php");}
else {header("location:addnewexpense.php");}

}


?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Home</title>
        <!-- Bootstrap Core CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!--SelfDefine CSS-->
        <link rel="stylesheet" href="styles.css" type="text/css" >
        <!--Own Styles-->
        <style type="text/css">
            .head{
                margin-top: 50px;
                margin-left: 200px;
            }
            .container_view{
                margin-top: 50px;
            }
            .bg_1{
                background-color: #008080;
                padding: 4px;
                border-radius: 5px;
            }
            .bg{
                background-color: #388a79;
            }
            .btn{
                background-color: white;
                border: 1px solid #008080;
                color:  #008080;
                text-align: center;
                width: 289px;
            }
            .border{
                margin: 0;
            }
        @media only screen and (max-width: 2000px) {
            .gly{
                position:fixed; top:80%; right:4%; 
                color: green;
  
        }
         @media only screen and (max-width: 411px) {
            .head{
            margin-top: 50px;
            margin-left: 20px;
        }
  
        }

         @media only screen and (max-width: 658px) {
            .gly{
                position:fixed; top:80%; right:4%; 
                color: green;
  
        }
        @media only screen and (max-width: 668px) {
           
        }
            .gly{
                position:fixed; top:80%; right:4%; 
                color: green;
        }

        </style>
        <!--Own Styles-->
    </head>

    <body style="padding-top: 50px;">
        <!-- Header -->
        <?php include"resource/header.php";?>
        <!--Header End-->

        <!--Home after plan content -->
        
            <div class="row heading">
                <div class="col-lg-6 col-sm-10 col-md-5 col-xs-12"><h1 class="head">Your Plans</h1></div>
                
            </div>
        
        
        <div class="container container_view" >
            <div class="row">
                <?php  while ($row = mysqli_fetch_array($select_query_result)) { ?>
                <div class="col-lg-4 col-sm-6 col-md-4">
                   <div class="container">
                        <div class="card border" style="width: 300px">
                            <div class="card-header bg">
                                <div class="row">
                                    <div class="col-lg-9 col-md-7 col-sm-7 col-xs-8" style="text-align: center;">
                                        <h4><?php echo $row['title'];?></h4>
                                    </div>
                                    <div class="col-lg-3 col-md-5 col-sm-5 col-xs-4"style="text-align: left;">
                                        <h4 dir="rtl"><?php echo $row['nopeople'] ?>&nbsp;<span class="glyphicon glyphicon-user"></span></h4>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <p>
                                    <div class="row">
                                        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
                                            <h5>Budget</h5>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                                            <h5 dir="rtl"><?php echo $row['initialbudget']." ₹" ?> </h5>
                                        </div>
                                    </div>
                    
                                    <div class="row">
                                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                                            <h5>Date</h5>
                                        </div>
                                        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
                                            <?php  
                                                $orgDate =$row['fromdate'] ;  
                                                $fromDate = date("d-m-Y", strtotime($orgDate));  
                                                //echo "New date format is: ".$newDate. " (MM-DD-YYYY)";  
                                                $orgDate =$row['todate'] ;  
                                                $toDate = date("d-m-Y", strtotime($orgDate));
                                            ?>
                                            <h5 style="float: right;"><?php echo $fromDate . " to " . $toDate ?></h5>
                                        </div>
                                    </div>
                                </p>
                            </div> 
                            <div class="card-footer">
                                <a href="home2.php?id=<?php echo $row['title'];?>" name="viewplan" class="btn btn-block"> View Plan</a>
                            </div>

                              <br>
                        </div>
                   </div>
                </div>
                <?php } ?>
                
                   
            </div>
            <br>
        </div>

       <a href="createnewplan.php"> <h1 class="gly"><span class="glyphicon glyphicon-plus-sign"></span></h1></a>
        <br>
        <!--Footer-->
        <?php include"resource/footer.php" ; ?>
        <!--Footer end-->


        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>



    </body> 
</html>


