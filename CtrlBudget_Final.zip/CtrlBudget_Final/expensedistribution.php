<?php 
session_start();
error_reporting(0);
//initialising the session variable
$title_1 = $_SESSION['title_1'] ;
$em = $_SESSION['Email'];
//Connection to the Database
$con = mysqli_connect("localhost", "root","", "ctrlproject") or die(mysqli_error($con));
// if anyone opens directly this page it transfer to you at logout.php
if (strlen($_SESSION['Email']) == 0) {
  header('location:logout.php');
  } 
//select query to select all from plandetail table
$se_1 = "SELECT *  FROM plandetail where email = '$em' and title = '$title_1'";
$select_query_result_1 = mysqli_query($con, $se_1) or die(mysqli_error($con));
//select query to select all from add newexpense
$se_2 = "SELECT *  FROM addnewexpense where email = '$em' and title = '$title_1' and choose ='1' ";
$select_query_result_2 = mysqli_query($con, $se_2) or die(mysqli_error($con));
//function to fetch the no. of people
function noofpeople($con, $amount) {
    global $em;
    global $title_1;
    //echo $em.$title_1;
    $se_2 = "SELECT *  FROM plandetail where email = '$em' and title = '$title_1'  ";
    $select_query_result_2 = mysqli_query($con, $se_2) or die(mysqli_error($con));
    $row = mysqli_fetch_array($select_query_result_2);
    return $row['nopeople'];
}
//function to take the initial budget from table
function initialbudget($con, $amount) {
    global $em;
    global $title_1;
    //echo $em.$title_1;
    $se_2 = "SELECT *  FROM plandetail where email = '$em' and title = '$title_1'  ";
    $select_query_result_2 = mysqli_query($con, $se_2) or die(mysqli_error($con));
    $row = mysqli_fetch_array($select_query_result_2);
    return $row['initialbudget'];
}
function initialbudget1($con) {
    global $em;
    global $title_1;
    //echo $em.$title_1;
    $se_2 = "SELECT *  FROM plandetail where email = '$em' and title = '$title_1'  ";
    $select_query_result_2 = mysqli_query($con, $se_2) or die(mysqli_error($con));
    $row = mysqli_fetch_array($select_query_result_2);
    return $row['initialbudget'];
}

//function to add all amount spend by person A
function addamountpersonA($con, $amount) {
    global $em;
    global $title_1;
    
    $se_2 = "SELECT *  FROM addnewexpense where email = '$em' and title = '$title_1' and choose ='1' ";
    $select_query_result_2 = mysqli_query($con, $se_2) or die(mysqli_error($con));
    $add = 0;
    while($row = mysqli_fetch_array($select_query_result_2)){
        
        $add = $add + $row['amountspend'];

    }
    return $add;
}
//function to add all amount spend by person B
function addamountpersonB($con, $amount) {
    global $em;
    global $title_1;
   
    $se_2 = "SELECT *  FROM addnewexpense where email = '$em' and title = '$title_1' and choose ='2' ";
    $select_query_result_2 = mysqli_query($con, $se_2) or die(mysqli_error($con));
    $add_2 = 0;
    while($row = mysqli_fetch_array($select_query_result_2)){
        $add_2 = $add_2 + $row['amountspend'];
    }
    return $add_2;
}
//function to add all spend amount by A and B both
function totalamountspend($con, $amount) {
    global $em;
    global $title_1;
    //echo $em.$title_1;
    $se_2 = "SELECT *  FROM addnewexpense where email = '$em' and title = '$title_1' ";
    $select_query_result_2 = mysqli_query($con, $se_2) or die(mysqli_error($con));
    $add_3 = 0;
    while($row = mysqli_fetch_array($select_query_result_2)){
        $add_3 = $add_3 + $row['amountspend'];
    }
    return $add_3;
}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Expense Distributions</title>
        <!-- Bootstrap Core CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <link rel="stylesheet" href="styles.css" type="text/css">
        <style type="text/css">
            .btn{
            background-color: white;
            border: 1px solid #008080;
            color:  #008080;
            text-align: center;
        }
        </style>

        
    </head>

    <body style="padding-top: 50px;">
        <!-- Header -->
        <?php include 'resource/header.php'; ?>
        <!--Header End-->


    <!--Expense distribution Page content -->
    <div class="container" style="padding-top: 50px;">
      <div class="row" >
        <center>
        <div class="col-lg-12">
                            <div class="container">
                        <div class="card">
                        <div class="card-header " style="background-color: #008080;border-radius: 5px;">
                        <div class="row bg">
                            <?php while ($row = mysqli_fetch_array($select_query_result_1)) { ?>
                            <div class="col-lg-6 col-md-6 col-xs-7 col-sm-6">
                                <center><h5><?php echo $row['title'] ?></h5></center>

                            </div>
                            <div class="col-lg-6 col-md-6 col-xs-5 col-sm-6">
                                <h5><span class="glyphicon glyphicon-user"></span><?php echo $row['nopeople'] ?></h5>

                            </div>
                        
                           
                        </div>
                        </div>
                        <div class="card-body">
                            <p>
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-xs-6 col-sm-6">
                                        <h5 style="text-align:  left">Initial Budget</h5>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-xs-6 col-sm-6">
                                        <h5><b><?php echo "₹ " .$row['initialbudget'] ?></b> </h5>
                                    </div>
                                </div>
                                <?php }?>
                                
                                <?php while ($row = mysqli_fetch_array($select_query_result_2)) { 
                                    global $spendbyA;
                                    $spendbyA = addamountpersonA($con, $row['amountspend']);
                                    global $spendbyB;
                                    $spendbyB = addamountpersonB($con, $row['amountspend']);
                                    global $totalamountspend;
                                    $totalamountspend = totalamountspend($con, $row['amountspend']);
                                    global $initialbudget ;
                                    $initialbudget = initialbudget($con,$row['amountspend']);
                                    global $noofpeople;
                                    $noofpeople = noofpeople($con, $row['amountspend']);
                                    global $indivisualshares;
                                    $indivisualshares = totalamountspend($con, $row['amountspend'])/$noofpeople;

                                }

                                ?>

                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-xs-6 col-sm-6">
                                        <h5 style="text-align:  left">Person A</h5>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-xs-6 col-sm-6">
                                        <h5 ><?php if ($spendbyA == NULL){
                                            
                                            //$spendbyA = 0;
                                            echo "₹ "."0";
                                            }
                                            else{
                                                echo "₹ ".$spendbyA;
                                            } ?>
                                        </h5>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-xs-6 col-sm-6">
                                        <h5 style="text-align:  left">Person B</h5>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-xs-6 col-sm-6">
                                        <h5 ><?php if ($spendbyB == NULL){
                                            
                                            //$spendbyB = 0;
                                            echo "₹ "."0";
                                            }
                                            else{
                                                echo "₹ ".$spendbyB;
                                            } ?>
                                        </h5>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-xs-6 col-sm-6">
                                        <h5 style="text-align:  left">Total Amount Spend</h5>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-xs-6 col-sm-6">
                                        <h5><b><?php if ($totalamountspend == NULL){
                                            
                                            //$totalamountspend = 0;
                                            echo "₹ "."0";
                                            }
                                            else{
                                                echo "₹ ".$totalamountspend;
                                            } ?></b>
                                        </h5>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-xs-6 col-sm-6">
                                        <h5 style="text-align: left">Remaining Amount</h5>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-xs-6 col-sm-6">
                                    <h5><b><?php if (($totalamountspend) == NULL){ 
                                            
                                            
                                            echo "₹ " .initialbudget1($con);
                                            }
                                            else{ ?>
                                            <b>
                                                <h5 <?php if (($initialbudget - $totalamountspend) > 0){ echo 'style = "color :green"';} elseif (($initialbudget - $totalamountspend) == 0) {echo 'style = "color :black"';} 
                                        else{echo 'style = "color :red"';} ?> ><?php if (($initialbudget - $totalamountspend) < 0 ) {echo "Overspend by ₹ ".abs($initialbudget - $totalamountspend);}
                                        else {echo "₹ ".($initialbudget - $totalamountspend);} ?></h5> </b>
                                            <?php } ?></b>
                                        </h5>  
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-xs-6 col-sm-6">
                                        <h5 style="text-align:  left">Indivisual Share</h5>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-xs-6 col-sm-6">
                                        <h5>
                                        <?php if ($indivisualshares == NULL){
                                            
                                            //$totalamountspend = 0;
                                            echo "₹ "."0";
                                            }
                                            else{
                                                echo "₹ " .$indivisualshares;
                                            } ?>
                                        </h5>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-xs-6 col-sm-6">
                                        <h5 style="text-align:  left">Person A</h5>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-xs-6 col-sm-6">
                                    <h5><?php if ($indivisualshares == NULL){ 
                                            
                                            
                                            echo "₹ " ."0";
                                            }
                                            else{ ?>
                                            <h5 <?php if (($spendbyA - $indivisualshares) > 0){ echo 'style = "color :green"';} elseif (($spendbyA - $indivisualshares) == 0) {echo 'style = "color :black"';} 
                                        else{echo 'style = "color :red"';} ?> ><?php if (($spendbyA - $indivisualshares) < 0 ) {echo "Owes ₹ ".abs($spendbyA - $indivisualshares);}
                                        elseif (($spendbyA - $indivisualshares) == 0) {echo 'All Settled up';}
                                        else {echo "Gets Back ₹ ".($spendbyA - $indivisualshares);} ?></h5>
                                            <?php } ?>
                                        </h5>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-xs-6 col-sm-6">
                                        <h5 style="text-align:  left">Person B</h5>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-xs-6 col-sm-6">
                                    <h5><?php if ($indivisualshares == NULL){ 
                                            
                                            
                                            echo "₹ " ."0";
                                            }
                                            else{ ?>
                                            <h5 <?php if (($spendbyB - $indivisualshares) > 0){ echo 'style = "color :green"';} elseif (($spendbyB - $indivisualshares) == 0) {echo 'style = "color :black"';} 
                                        else{echo 'style = "color :red"';} ?> ><?php if (($spendbyB - $indivisualshares) < 0 ) {echo "Owes ₹ ".abs($spendbyB - $indivisualshares);}
                                        elseif (($spendbyB - $indivisualshares) == 0) {echo 'All Settled up';}
                                        else {echo "Gets Back ₹ ".($spendbyB - $indivisualshares);} ?></h5>
                                            <?php } ?>
                                        </h5>
                                    </div>
                                </div>

                            </p>
                            
                        </div> 
                        
                    </div>
                   </div>
                        </div>
                        
                        <a href="addnewexpense.php" class="btn"><span class="glyphicon glyphicon-arrow-left"></span> Go Back</a>
                        </center>
                    

      </div>
    </div>

    
    <!--end of expense distribution Page content -->

               <!--Footer-->
         <?php include"resource/footer.php"?>
        <!--Footer end-->

        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    </body> 
</html>