-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 14, 2020 at 07:03 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ctrlproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `addnewexpense`
--

CREATE TABLE `addnewexpense` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `expensename` varchar(255) NOT NULL,
  `dated` varchar(255) NOT NULL,
  `amountspend` varchar(255) NOT NULL,
  `choose` varchar(255) NOT NULL,
  `uploadedimage` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addnewexpense`
--

INSERT INTO `addnewexpense` (`id`, `title`, `email`, `expensename`, `dated`, `amountspend`, `choose`, `uploadedimage`) VALUES
(1, 'Goa', 'shiva@gmail.com', 'Food', '2019-04-10', '30', '1', ''),
(2, 'Goa', 'shiva@gmail.com', 'Food Bill', '2019-04-10', '30', '2', 'img/14-09-2020-1600059740.jpg'),
(3, 'Goa', 'shiva@gmail.com', 'Travel bill', '2019-04-10', '50', '1', 'img/14-09-2020-1600059761.jpg'),
(4, 'Goa', 'shiva@gmail.com', 'Travel', '2019-04-10', '50', '2', '');

-- --------------------------------------------------------

--
-- Table structure for table `newplan`
--

CREATE TABLE `newplan` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `initialbudget` varchar(255) NOT NULL,
  `noofpeople` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newplan`
--

INSERT INTO `newplan` (`id`, `email`, `initialbudget`, `noofpeople`) VALUES
(1, 'shiva@gmail.com', '60', '2'),
(2, 'shiva@gmail.com', '60', '2');

-- --------------------------------------------------------

--
-- Table structure for table `plandetail`
--

CREATE TABLE `plandetail` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `fromdate` varchar(255) NOT NULL,
  `todate` varchar(255) NOT NULL,
  `initialbudget` varchar(255) NOT NULL,
  `nopeople` varchar(255) NOT NULL,
  `person1name` varchar(255) NOT NULL,
  `person2name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `plandetail`
--

INSERT INTO `plandetail` (`id`, `email`, `title`, `fromdate`, `todate`, `initialbudget`, `nopeople`, `person1name`, `person2name`) VALUES
(1, 'shiva@gmail.com', 'Goa', '2019-04-10', '2019-04-12', '60', '2', 'Shiva', 'Ram');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `Id` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Contact` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`Id`, `Name`, `Email`, `Password`, `Contact`) VALUES
(1, 'Shiva', 'shiva@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '8965328965');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addnewexpense`
--
ALTER TABLE `addnewexpense`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newplan`
--
ALTER TABLE `newplan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `plandetail`
--
ALTER TABLE `plandetail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addnewexpense`
--
ALTER TABLE `addnewexpense`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `newplan`
--
ALTER TABLE `newplan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `plandetail`
--
ALTER TABLE `plandetail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
