<?php
session_start();
//Connection to database
$con = mysqli_connect("localhost", "root","", "ctrlproject") or die(mysqli_error($con));
//if login button is pressed or set
if (isset($_POST['login'])){
    // takes all data from form
        $email = $_POST['email'];
        $password = ($_POST['password']);
        //Escaping from special characters
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $password = md5($_POST['password']);
        //use select query to select the data form the database.
        $select_query = "select * from signup where Email = '$email' AND Password = '$password'";
        $result = mysqli_query($con, $select_query) or die(mysqli_error($con));
        $total_rows_fetched = mysqli_num_rows($result);
        
        //If row fetched is equalto one means email id is registerd then login it
        if ($total_rows_fetched == 1){
            $_SESSION['Email'] = $email; 
            $select_query_1 = "select * from plandetail where Email = '$email'";
            $result_query = mysqli_query($con, $select_query_1) or die(mysqli_error($con));
            $total_rows_fetched_1 = mysqli_num_rows($result_query);
            echo $total_rows_fetched_1;
            $row = mysqli_fetch_array($result_query);
            $title=$row['title'];
                
            if ($total_rows_fetched_1 != 0){
                echo "<script>alert('Login Successfull')</script>";
                $_SESSION['Email'] = $email;
                $_SESSION['title'] = $title;
                    header('location:home2.php');
                }
                else{
                    header('location:home.php');
                }
            }
        else{
            echo "<script>alert('Login Failed')</script>";
            echo ("<script>location.href='login.php'</script>");
        }

        }

 // Sign Up in Login page
    if (isset($_POST['signup_login'])){
        header('location:signup.php');
       
        }

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Login</title>
        <!-- Bootstrap Core CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!--Style.Css-->
        <link rel="stylesheet" href="styles.css" type="text/css">
         
    </head>
    <body style="padding-top: 100px;">
        <!-- Header -->
        <?php include 'resource/header.php'; ?>
        <!--Header End-->

        <br>

        <!--Login Form-->
        <div class="container-fluid" >
            <div class="row">
                <div class="container">
                    <div class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3 border" >
                        <h3 style="text-align: center;">Login</h3>
                        <form  action="login.php" method="POST" >
                            <div class="form-group">
                                <label for="email" >Email-Id</label>
                                <input class="form-control" placeholder="Email-id" type="email" name="email"  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$"  required>
                            </div>
                        
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" placeholder="Password" name="password" pattern=".{6,}" required>
                                
                            </div>
                            <br><br>
                            <button type="submit" name="login" class="btn btn-change btn-block" style="float: right;"><span class="glyphicon glyphicon-log-in"></span> Login</button>
                        </form>
                        <br>
                        <br>
                        <br>

                        <p class="signupacc">Don't Have an Account? <a href="signup.php"> Click here to signup</a></p>
                       
                    </div>
                </div>
            </div>
        </div>
        
        <br><br>
        <center>
    
            
            
  
        </center>

        <!-- End of Login Form-->
                           
        <!--Footer-->
        <?php include 'resource/footer.php'?>

        <!--Footer end-->

        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html>