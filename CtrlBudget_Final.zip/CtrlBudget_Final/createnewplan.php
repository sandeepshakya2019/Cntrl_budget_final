<?php 
    session_start();
    //take session variable from the previous page
    $em = $_SESSION['Email'];
    // if anyone opens the page direcly the it send to logout.php
    if (strlen($_SESSION['Email']) == 0) {
      header('location:logout.php');
      } 
    //connection to the databse
    $con = mysqli_connect("localhost", "root","", "ctrlproject") or die(mysqli_error($con));
    //if the button whose name is newplan is pressed 
    if (isset($_POST['newplan'])){
        $initialbudget = $_POST['initialbudget'];
        $noofpeople = $_POST['noofpeople'];
        //use insert query to insert the data into newplan table
        $user_registration_query = "insert into newplan (email,initialbudget,noofpeople) values ('$em','$initialbudget', '$noofpeople')";
        $user_registration_submit = mysqli_query($con, $user_registration_query) or die(mysqli_error($con));

        $_SESSION['Email'] = $em;
        $_SESSION['initialbudget'] = $initialbudget;
        $_SESSION['noofpeople'] = $noofpeople ;

        header('location:plandetail.php');
    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Create New Plan</title>
        <!-- Bootstrap Core CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <link rel="stylesheet" href="styles.css" type="text/css">

        <style>
            .btn {
              background-color: white;
              border: 1px solid #008080;
              color:  #008080;
              text-align: center;
              font-size: 16px;
              margin: 4px 2px;
              transition: 0.3s;
            }
            .planCreate{
              margin-top: 50px;
            }
            h3{
              margin:0;
              color: white;
              padding-top: 5px;
              padding-bottom: 5px;
              text-align: center;
              background-color: #388a79;        
            }

            .btn:hover {
              background-color: #008080;
              color: white;
            }
        </style>
    </head>

    <body style="padding-top: 50px;">
        <!-- Header -->
        <?php include 'resource/header.php'; ?>
        <!--Header End-->

        <!--Create a new plan Page content -->
        <div class="container planCreate" id="content">

                <div class="row">
                    <div class="container ">
                        <div class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3 border ">
                            <h3>Create New Plan</h3>
                            <form  action="createnewplan.php" method="POST">
                                
                                <div class="form-group">
                                    <label for="initialbudget" class="paddings">Initial Budget</label>
                                    <input class="form-control" type="number" placeholder="Initail Budget (Ex.4000)" name="initialbudget" min='50'  required>
                                </div>
                            
                                <div class="form-group">
                                    <label for="number" class="paddings">How many peoples you want to add in you group</label>
                                    <input type="number" class="form-control" placeholder="No. of Peoples" name="noofpeople"  min='1' required>
                                </div>
                                
                                <br>
                                <button type="submit" name="newplan" class="btn btn-block button_hover"><span class="glyphicon glyphicon-log-in"></span> Next</button>
                                
                            </form>
                        </div>
                    </div>
                </div>
            </div>


        <!--end of Create a new plan Page content -->

        <!--Footer-->
        <?php include"resource/footer.php"?>
        <!--Footer end-->

        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    </body> 
</html>