
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Welcome- Ct₹lBudget</title>
        <!-- Bootstrap Core CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!--Self Defined CSS-->
        <link rel="stylesheet" href="styles.css" type="text/css">
    </head>

    <body style="padding-top: 50px;">
        <!--Header-->
        <?php include 'resource/header.php'; ?>
         <!--end of Header-->
         
         <!--Main Content-->
        <div id="content">
            <div id = "banner_image">
                <div class="container"> 
                    <center>
                        <div id="banner_content">
                            <h3>We help you to control your budget</h3>
                            <br/>
                            <a  href="login.php" class="btn btn-danger btn-lg active">Start Today</a>
                        </div>
                    </center>
                </div>
            </div>
        </div>
        <!--Main Content end-->

        <!--Footer-->
        <?php include 'resource/footer.php'?>
        <!--Footer end-->

        <!--Bootstrap JS Files-->

        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    </body> 
</html>